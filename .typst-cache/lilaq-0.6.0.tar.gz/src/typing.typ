#import "@preview/elembic:1.1.1" as e: selector, cond-set, show_
#import "model/grid.typ": grid
#import "model/label.typ": label
#import "model/title.typ": title
#import "model/legend.typ": legend
#import "model/tick.typ": tick, tick-label
#import "model/spine.typ": spine
#import "model/diagram.typ": diagram
#import "model/errorbar.typ": errorbar
#import "plot/violin.typ": violin-boxplot, violin-extremum

#let set_ = e.set_
#let fields = e.fields
#let set-grid = e.set_.with(grid)
#let set-title = e.set_.with(title)
#let set-label = e.set_.with(label)
#let set-legend = e.set_.with(legend)
#let set-tick = e.set_.with(tick)
#let set-tick-label = e.set_.with(tick-label)
#let set-spine = e.set_.with(spine)
#let set-diagram = e.set_.with(diagram)
#let set-errorbar = e.set_.with(errorbar)
#let set-violin-boxplot = e.set_.with(violin-boxplot)
#let set-violin-extremum = e.set_.with(violin-extremum)
